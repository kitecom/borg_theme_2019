jasmine.DEFAULT_TIMEOUT_INTERVAL = 60 * 1000;

module.exports = {
	credentials: {
		email: 's@gurin.com'
	,	password: 'Pepe8080__$$'
	,	roleId: '3'
	,	account: '3690872'
	}
};