var _ = require('underscore')
,	suitetalk = require('suitetalk')
,	args = require('yargs').argv
,	Tool = require('./index')

console.log('hello from ns uplodaer')